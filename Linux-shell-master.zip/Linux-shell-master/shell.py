from os import system

# For autocomplete and suggestions
from fuzzywuzzy import fuzz

shell_commands = [ 
    "man",  
    "file",  
    "mkdir",
    "cat", 
    "rmdir", 
    "rename", 
    "free",
    "ps",
    "searcher",
    "clear", 
    "exit"
]

def closest_command_finder(command):

    """
    Function to take a command string, find the closest matching command and return a possible match from the existing set of shell commands.
    ...
    Parameters
    ----------
    command : str 
        The command to be analysed to find the closest match
    """

    closest_command = command
    sys_command = shell_commands[0]
    fuzzratio = fuzz.ratio(command, sys_command)
    for sys_command in shell_commands:
        if fuzz.ratio(command, sys_command) > fuzzratio and fuzz.ratio(command, sys_command)!=0:
            fuzzratio = fuzz.ratio(command, sys_command)
            closest_command = sys_command

    return closest_command

def shell():

    """
    Function that runs the shell.
    """

    startup = 1
    from_cmd_error = 0

   

    while 1:
        if startup == 1:
            startup = startup + 1
            _ = system('clear')
            print("Commands")
            print("============")
            print("- mkdir : Creates a new directory")
            print("- rmdir : Removes an existing empty directory") 
            print("- rename : Renames an existing directory")
            print("- file : Returns information about a file")
            print("- cat : Reads the contents of the file") 
            print("- searcher : Searches for a file in the file system") 
            print("- free : Display amount of free memory and used memory in the system")
            print("- ps : Lists all the running processes")
            print("- man : Provides a Manual for all the commands")


        if (from_cmd_error == 0):
            userinput = input("\033[1;32;40mmmehul@shell\033[0m$ ")
            pass
        else:
            userinput = closest_command + " " + userinput
            from_cmd_error = 0
        
        input_arr = userinput.split()

        if(len(input_arr) == 1 and (input_arr[0] in shell_commands) and input_arr[0] != 'exit' and input_arr[0] != 'clear' and input_arr[0] != 'free' and input_arr[0] != 'ps'):
            system('python3 ' + input_arr[0] + '.py --help')
        elif(input_arr[0] == shell_commands[0]):
            system('python ' + input_arr[1] + '.py ' + input_arr[0])
        elif(input_arr[0] == shell_commands[1]):  
            system('python3 file.py ' + input_arr[1])
        elif(input_arr[0] == shell_commands[2]):  
            if len(input_arr) == 3:
                system('python3 mkdir.py ' + input_arr[1] + ' ' + input_arr[2])
            elif len(input_arr) == 2:
                system('python3 mkdir.py ' + input_arr[1])
        elif input_arr[0] == shell_commands[3]:
            if len(input_arr) == 2:
                system('python3 cat.py ' + input_arr[1])
        elif(input_arr[0] == shell_commands[4]):  
            if len(input_arr) == 3:
                system('python3 rmdir.py ' + input_arr[1] + ' ' + input_arr[2])
            elif len(input_arr) == 2:
                system('python3 rmdir.py ' + input_arr[1])	
        elif(input_arr[0] == shell_commands[5]):
            if len(input_arr) == 3:
                system('python3 rename.py ' + input_arr[1] + ' ' + input_arr[2])
            elif len(input_arr) == 2:
                system('python3 rename.py ' + input_arr[1])
        elif(input_arr[0] == shell_commands[6]): 
            if len(input_arr) == 3:
                system('python3 free.py ' + input_arr[1] + input_arr[2])
            elif len(input_arr) == 2:
                system('python3 free.py ' + input_arr[1])
            elif len(input_arr) == 1:
                system('python3 free.py')
        elif(input_arr[0] == shell_commands[7]):
            if len(input_arr) == 2:
                system('python3 ps.py ' + input_arr[1])
            else: 
                system('python3 ps.py')
        elif(input_arr[0] == shell_commands[8]):
            if len(input_arr) == 3:
                system('python3 searcher.py ' + input_arr[1] + input_arr[2])
            elif len(input_arr) == 2:
                system('python3 searcher.py ' + input_arr[1])
        elif(input_arr[0] == shell_commands[9]):  # clear command
            _ = system('clear')
        elif(input_arr[0] == shell_commands[10]):  # exit command
            exit(0)
        else:
            closest_command = closest_command_finder(input_arr[0])
            userinput = input(input_arr[0] + ": unknown command. Did you mean " + closest_command + "? (y/n): ")
            if userinput == 'y' or userinput == 'Y':
                userinput = input("\033[1;32;40mmmehul@shell\033[0m$ " + closest_command)
                from_cmd_error = 1;
            else:
                continue

shell()
